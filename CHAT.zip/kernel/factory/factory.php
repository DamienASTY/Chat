<?php
namespace Kernel\Factory;

class Factory {

    private $_user;
    private $_passwords;
    private $_db; //? L'instance PDO :)

    public function setConnection(string $user, string $password, string $host, string $dbname) {
        try {
            $this->_user = $user;
            $this->_passwords = $password;
            $this->_db = new \PDO('mysql:host='.$host.';dbname='.$dbname, $user, $password);
        }
        catch (\PDOException $e) {
            return $e->getMessage();
        }
    }

    public function getInstance(): PDO { return $this->_db; }

}