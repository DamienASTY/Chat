<?php
require_once "../vendor/autoload.php";

$db = new Kernel\Factory\Factory();
$db->setConnection('root', '', 'localhost', 'chat');
var_dump($db);

//* création d'un utilisateur
$user = new Controller\UserController("Damie,", "Pelaez", "dpb@gmail.com", "Berna123*");
var_dump($user);
//* fin création d'un utilisateur
$entity = new Entity\UserEntity($db);
$entity->create($user);

echo "test";