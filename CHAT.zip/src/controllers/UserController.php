<?php
namespace Controller;

class UserController {

    private string $_firstname;
    private string $_lastname;
    private string $_email;
    private string $_password;

    public function __construct(string $firstname, string $lastname, string $email, string $password) {
        try {
            $this->setFirstname($firstname);
            $this->setLastname($lastname);
            $this->setEmail($email);
            $this->setPassword($password);
        }
        catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    public function getFirstname(): string { return $this->_firstname; }
    public function getLastname(): string { return $this->_lastname; }
    public function getEmail(): string { return $this->_email; }
    public function getPassword(): string { return $this->_password; }

    public function setFirstname(string $firstname) {
        $this->_firstname = $firstname;
    }

    public function setLastname(string $lastname) {
        $this->_lastname = $lastname;
    }

    public function setEmail(string $email) {
        //? Regex email adress
        if(preg_match('#^[a-z0-9._-]+@[a-z0-9.+-]{2,}\.[a-z]{2,4}$#', $email)) {
            $this->_email = $email;
        }
    }

    public function setPassword(string $password) {
        //! Je prend pas argon2id, pour ne pas devoir changer de méthode de log si l'algo est modifié dans le futur.
        $this->_password = password_hash($password, PASSWORD_DEFAULT);
    }
}