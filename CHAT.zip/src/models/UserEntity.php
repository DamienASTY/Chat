<?php
namespace Entity;

class UserEntity {

    private $_db;

    public function __construct($db) {
        $this->_db = $db;
    }

    public function getAll() {
        echo "all";
    }

    public function getOneById(uint $id) {
        echo "oneById";
    }

    public function create($user) {
        try {
            $req = $this->_db->getDb()->prepare('INSERT INTO user (firstname, lastname, email, password) VALUES (:firstname, :lastname, :email, :password)');
            $req->execute(array(
                "firstname" => $user->getFirstName(),
                "lastname" => $user->getLastName(),
                "email" => $user->getEmail(),
                "password" => $user->getPassword()    
            ));
        }
        catch (\Exception $e) {
            return $e->getMessage();
        }
    }

}